import sys; sys.path.insert(0,"/home/claude/trishula")
import pandas as pd, numpy as np, plotly.graph_objects as go
from core import dealer as DL
from tabs import tastier as TT
D="../d1112b"; E="2026-11-12"
cs=pd.read_parquet(f"{D}/chain_snapshots.parquet"); c1=pd.read_parquet(f"{D}/opt1m_backfill.parquet")
ch=cs[(cs.exp==E)&(cs.ts_ms==cs[cs.exp==E].ts_ms.max())]
L=ch.drop_duplicates("sym")[["sym","strike","cp","oi","iv","dsign"]].reset_index(drop=True)
L["iv"]=L.iv.where(L.iv>0, L.groupby("cp").iv.transform("median")).fillna(0.2)
spx=pd.read_parquet(f"{D}/spx1m.parquet"); spx["t"]=pd.to_datetime(spx.ts_ms,unit="ms",utc=True).dt.tz_convert("America/New_York").dt.tz_localize(None)
t0=pd.Timestamp("2026-11-12 09:30"); t1=pd.Timestamp(c1.m.max())
idx=pd.date_range(t0,t1.floor("5min"),freq="5min")
c=c1[c1.sym.isin(set(L.sym))&(c1.m>=t0)&(c1.m<=t1)].copy(); c["b"]=c.m.dt.floor("5min"); c["net"]=c.askv.fillna(0)-c.bidv.fillna(0)
net=c.pivot_table(index="b",columns="sym",values="net",aggfunc="sum").reindex(idx).fillna(0).cumsum().reindex(columns=L.sym).fillna(0).values
sp=spx.set_index("t").close.reindex(idx,method="ffill").values
bars=spx[spx.t>=t0].rename(columns=dict(open="o",high="h",low="l",close="c"))
K=L.strike.values; ks=np.unique(K); ks=ks[(ks>=7540)&(ks<=7720)]
for beta in (True,False):
    base=DL.signs(L,beta)*L.oi.values
    Z=np.zeros((len(ks),len(idx)))
    for j,t in enumerate(idx):
        T=DL._t_years(E,t); S=sp[j]
        g=DL._gamma(np.array([[S]]),K[None,:],T,L.iv.values[None,:])[0]*100*S*S*0.01
        v=(base-net[j])*g
        s=pd.Series(v).groupby(K).sum().reindex(ks).fillna(0).values
        Z[:,j]=s
    print("beta",beta,"share of positive cells",(Z>0).mean().round(2))
    Zn=Z/np.maximum(np.abs(Z).max(axis=0,keepdims=True),1)
    cs_=[[0,"#d1263a"],[0.45,"#3a0d18"],[0.5,"#0b0f14"],[0.55,"#0d2a5a"],[1,"#2f8bff"]]
    f=go.Figure(go.Heatmap(z=Zn,x=idx,y=ks,zmin=-1,zmax=1,colorscale=cs_,showscale=False))
    f.add_candlestick(x=bars.t,open=bars.o,high=bars.h,low=bars.l,close=bars.c,increasing_line_color="#2ecc71",decreasing_line_color="#ff4d5e")
    f.update_layout(xaxis_rangeslider_visible=False,template="plotly_dark",paper_bgcolor="#0e1117",plot_bgcolor="#0e1117",
                    title=f"PROTOTYPE · dealer γ BY STRIKE through time (β={'flow' if beta else 'naive'}) · 12 Nov",height=520,width=900,showlegend=False)
    f.update_yaxes(range=[7540,7720],side="right")
    f.write_image(f"strike_{int(beta)}.png")
