import json, sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/trishula"); sys.path.insert(0, "../l48")
exec(open("review.py").read().split("# 1. data quality")[0])
from grid import run, GRID, label
A = pd.read_pickle("../l48/all.pkl")      # 22-day all-prints history results per rule
L = pd.DataFrame([label(k) for k in range(len(GRID))])
rows = []
for fl in ("0DTE", "0+1DTE"):
    for m in (1, 5):
        r5 = run(LN.bars(D["2026-11-05"], fl, "single-leg", m), m); r9 = run(LN.bars(D["2026-11-09"], fl, "single-leg", m), m)
        a5 = run(LN.bars(D["2026-11-05"], fl, "all", m), m); a9 = run(LN.bars(D["2026-11-09"], fl, "all", m), m)
        d = L.copy(); d["flow"] = fl; d["bar"] = m
        d["nov5"] = r5[:, 0]; d["nov9"] = r9[:, 0]; d["tr5"] = r5[:, 1]; d["tr9"] = r9[:, 1]
        d["all5"] = a5[:, 0]; d["all9"] = a9[:, 0]
        rows.append(d)
S = pd.concat(rows, ignore_index=True)
S["sl"] = S.nov5 + S.nov9; S["all"] = S.all5 + S.all9; S["both_up"] = (S.nov5 > 0) & (S.nov9 > 0)
key = ["flow", "bar", "lean", "mode", "X", "confirm", "cool", "skip10", "grey"]
H = A[A.ver == "ALL"][key + ["hist_tot", "hist_up", "h1", "h2"]]
S = S.merge(H, on=key, how="left"); S.to_pickle("two_day.pkl")
pd.set_option("display.width", 250); pd.set_option("display.max_rows", 200)
print(f"rules positive on BOTH days (single-leg): {S.both_up.mean():.0%}  ·  positive both days AND on 22 history days: {(S.both_up & (S.hist_tot > 0)).mean():.1%}")
print("\nMAIN EFFECTS — mean 2-day single-leg total (pts) · share positive on both days · mean 22-day history (all prints)")
for k in ["bar", "flow", "lean", "mode", "X", "confirm", "cool", "skip10", "grey"]:
    g = S.groupby(k).agg(sl=("sl", "mean"), both=("both_up", "mean"), hist=("hist_tot", "mean"))
    print(f"\n{k}:\n" + g.round(2).T.to_string())
S1 = S[S.bar == 1]
print("\n\nTWO-WAY (1-min bars) — mean 2-day single-leg total")
for a, b in (("lean", "X"), ("lean", "mode"), ("mode", "X"), ("confirm", "cool"), ("grey", "mode"), ("lean", "confirm")):
    print(f"\n{a} × {b}:"); print(S1.pivot_table(index=a, columns=b, values="sl", aggfunc="mean").round(0).to_string())
print("\n\nTHREE-WAY: 1-min, rolling windows only — mode × X × confirm (mean 2-day SL total)")
S2 = S1[S1.lean.str.startswith("roll")]
print(S2.pivot_table(index=["mode", "confirm"], columns="X", values="sl", aggfunc="mean").round(0).to_string())
print("\n\nBEST RULES that are positive on BOTH days, ranked by the WORSE of the two days (robustness), with their 22-day history:")
S["worst"] = S[["nov5", "nov9"]].min(1)
cols = key + ["nov5", "tr5", "nov9", "tr9", "all5", "all9", "hist_tot", "hist_up", "h1", "h2"]
print(S[S.both_up].sort_values("worst", ascending=False)[cols].head(25).round(1).to_string(index=False))
print("\nSame, but ALSO positive on the 22 history days (both halves):")
print(S[S.both_up & (S.hist_tot > 0) & (S.h1 > 0) & (S.h2 > 0)].sort_values("worst", ascending=False)[cols].head(20).round(1).to_string(index=False))
print("\nNeighbours of rule A (1-min 0DTE roll 15m sticky, confirm, cool 10, hold, skip off) by X and window:")
nb = S[(S.bar == 1) & (S.flow == "0DTE") & (S["mode"] == "sticky") & (S.confirm) & (S.cool == 10) & (S.grey == "hold") & (~S.skip10) & S.lean.str.startswith("roll")]
print(nb.pivot_table(index="lean", columns="X", values="sl").round(0).reindex(["roll 5m", "roll 10m", "roll 15m", "roll 20m", "roll 30m", "roll 45m", "roll 60m"]).to_string())
print("\n  same block, 22-day history (all prints):")
print(nb.pivot_table(index="lean", columns="X", values="hist_tot").round(0).reindex(["roll 5m", "roll 10m", "roll 15m", "roll 20m", "roll 30m", "roll 45m", "roll 60m"]).to_string())
