import json, sys, pickle, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/trishula"); sys.path.insert(0, "../l48")
exec(open("review.py").read().split("# 1. data quality")[0])
from grid import run, GRID, label
# 3. PRICE-ONLY TWIN of rule A: same sticky/confirm/cooldown machine, but 'lean' = last-15-min SPX move in points / k
def mom_bars(b, win, k):
    c = b.c.values; m = pd.Series(c).diff(win).fillna(0).values / k     # crosses ±X(=1) when the 15m move crosses ±k pts
    return m
def ruleA_on(b, sig, X=1.0, conf=True, cool=10):
    h, l, c = b.h.values, b.l.values, b.c.values; col = np.zeros(len(c), int); stk = 0; last = 0; g = 99
    for i in range(len(c)):
        v = sig[i]; s = 1 if v >= X else (-1 if v <= -X else 0)
        if s: stk = s
        w = stk
        if w and conf and (i < 2 or (w > 0 and not c[i] > max(h[i-1], h[i-2])) or (w < 0 and not c[i] < min(l[i-1], l[i-2]))): w = 0
        if w and cool and last and w == -last and g < cool: w = 0
        col[i] = w
        if w: g, last = 0, w
        else: g += 1
    return col
print("3. RULE A vs its PRICE-ONLY TWIN (same machine; signal = last-15-min SPX move ≥ k points instead of lean ≥ 8%)")
for k_ in (5, 8, 12, 15, 20):
    res = {}
    for k, d in D.items():
        b = LN.bars(d, "0DTE", "single-leg"); tr = LN.trades(b, ruleA_on(b, mom_bars(b, 15, k_)), True); res[k] = (tr.net.sum(), len(tr))
    # history days (no lean needed: price only)
    H = pickle.load(open("../l47/bars.pkl", "rb")); hn = []
    for (dd, m, f), b in sorted(H.items()):
        if m != 1 or f != "0DTE" or len(b) < 60 or dd == "2026-11-04": continue
        tr = LN.trades(b, ruleA_on(b, mom_bars(b, 15, k_)), True); hn.append(tr.net.sum())
    print(f"  k={k_:2d} pts: 5 Nov {res['2026-11-05'][0]:+7.1f} ({res['2026-11-05'][1]} tr) · 9 Nov {res['2026-11-09'][0]:+6.1f} ({res['2026-11-09'][1]} tr) · 22 history days total {sum(hn):+7.1f}, {sum(np.array(hn)>0)}/22 up")
print("  (rule A itself, single-leg: 5 Nov +204.1 (2 tr) · 9 Nov +52.5 (4 tr); on 22 history days, all prints: +14)")
# 4. full grid: SL vs ALL vs time-shifted SL
print("\n4. ALL 7,680 RULES × 0DTE/0+1DTE × 1/5-min on the two days")
rng = np.random.default_rng(5); rows = []
for fl in ("0DTE", "0+1DTE"):
    for m in (1, 5):
        tot = {}
        for kind in ("single-leg", "all"):
            tot[kind] = sum(run(LN.bars(d, fl, kind, m), m)[:, 0] for d in D.values())
        nulls = []
        for rep in range(10):
            s = 0
            for d in D.values():
                b = LN.bars(d, fl, "single-leg", m).copy(); n = len(b); b[["b", "r"]] = np.roll(b[["b", "r"]].values, int(rng.integers(n // 4, 3 * n // 4)), axis=0)
                s = s + run(b, m)[:, 0]
            nulls.append(s)
        nu = np.stack(nulls)
        rows.append(dict(flow=fl, bar=m, SL_profitable=f"{np.mean(tot['single-leg'] > 0):.0%}", ALL_profitable=f"{np.mean(tot['all'] > 0):.0%}",
                         NULL_profitable=f"{np.mean(nu > 0):.0%}", SL_median=round(np.median(tot['single-leg']), 1), ALL_median=round(np.median(tot['all']), 1),
                         NULL_median=round(np.median(nu), 1), SL_beats_ALL=f"{np.mean(tot['single-leg'] > tot['all']):.0%}",
                         SL_best=round(tot['single-leg'].max(), 1), NULL_best_avg=round(nu.max(1).mean(), 1)))
print(pd.DataFrame(rows).to_string(index=False))
