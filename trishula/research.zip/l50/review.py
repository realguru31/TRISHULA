import json, sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/trishula"); sys.path.insert(0, "../l48")
from core import lean as LN
_orig = LN.bars
def bars_day(d, flow="0DTE", kind="single-leg", bar=1):
    sp = [r for r in d["spx"] if pd.Timestamp(r[0], unit="ms", tz="UTC").tz_convert("America/New_York").strftime("%Y-%m-%d") == d["day"]]
    return _orig(dict(d, spx=sp), flow, kind, bar)
LN.bars = bars_day
D = {k: json.load(open(f"../lh1/lean_{k}.json")) for k in ("2026-11-05", "2026-11-09")}
pd.set_option("display.width", 220)
# 1. data quality
print("1. DATA QUALITY")
for k, d in D.items():
    for fl in ("0DTE", "0+1DTE"):
        s = LN.bars(d, fl, "single-leg"); a = LN.bars(d, fl, "all")
        z = int(((s.b + s.r) == 0).sum())
        sh = (s.b + s.r).sum() / (a.b + a.r).sum()
        hr = ((s.b + s.r).groupby(s.index.hour).sum() / (a.b + a.r).groupby(a.index.hour).sum()).round(2).to_dict()
        ls, la = (s.b.sum() - s.r.sum()) / (s.b + s.r).sum(), (a.b.sum() - a.r.sum()) / (a.b + a.r).sum()
        print(f"  {k} {fl:6s}: {len(s)} min, empty minutes {z}, single-leg share {sh:.0%} (by hour {hr}), day lean SL {ls:+.1%} / ALL {la:+.1%}, flow SL {(s.b+s.r).sum():,.0f} $M")
# 2. information content: rolling lean vs forward SPX move (rank corr), SL vs ALL, vs time-shifted
print("\n2. DOES THE LEAN PREDICT? rank corr of rolling lean with the next 10/20/30-min SPX move (per day; |r| < ~0.10 is noise at 1-min overlap)")
from scipy.stats import spearmanr
for k, d in D.items():
    for fl in ("0DTE", "0+1DTE"):
        for win in (5, 15, 30):
            out = []
            for kind in ("single-leg", "all"):
                b = LN.bars(d, fl, kind); l = LN.lean_series(b, "roll", win); c = b.c.values
                past = pd.Series(c).diff(win).values
                r = [spearmanr(l[win:-h], c[win + h:] - c[win:-h]).statistic for h in (10, 20, 30)]
                rp = spearmanr(l[win:], past[win:]).statistic
                out.append(f"{kind[:3].upper()} fwd10/20/30 {r[0]:+.2f} {r[1]:+.2f} {r[2]:+.2f} | with PAST {win}m move {rp:+.2f}")
            print(f"  {k} {fl:6s} roll {win:2d}m: " + "   ".join(out))
