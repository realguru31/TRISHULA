"""L48 — lean candles, EVERY combination, executed as trades.
4 Nov (user's Colab zip): three flow versions
   ALL  candle bid/ask split, every print (spreads included)
   HYB  what the viewer uses: single-leg replayed prints where the replay reaches, candle split before that
   SLE  single-leg ESTIMATE all day: each contract's candle ask/bid volume × that contract's single-leg share on that
        side, measured from its replayed prints (Lee-Ready). Proxy — the share is measured late in the day.
22 history sessions (24 Sep–23 Oct): ALL only (no prints exist for those days).
Execution: enter at the close of the bar whose colour differs from the position; 'flat' = grey closes the trade,
'hold' = grey keeps it (stop-and-reverse only on the opposite colour). Flat at the last bar. 0.5 SPX pt per round trip."""
import pickle, itertools, sys
import numpy as np, pandas as pd
from numba import njit
from scipy.special import ndtr
B = "/tmp/claude-0/-home-claude/dee3bb00-9e12-54e5-970a-89cb0441116b/scratchpad"
N4 = f"{B}/n4"
COST = 0.5
_t = lambda ms: pd.to_datetime(ms, unit="ms", utc=True).dt.tz_convert("America/New_York").dt.tz_localize(None)


# ── 4 Nov bars ──────────────────────────────────────────────────────────────────────────────────────────────────
def nov4_bars():
    c = pd.read_pickle(f"{N4}/candles.pkl"); lg = pd.read_pickle(f"{N4}/legs.pkl"); pr = pd.read_pickle(f"{N4}/prints.pkl")
    day0, day1 = pd.Timestamp("2026-11-04 09:30"), pd.Timestamp("2026-11-04 15:59")
    s = c[c.sym.str.startswith("SPX{")].copy(); s["t"] = _t(s.ts_ms); s = s.drop_duplicates("t").set_index("t").sort_index()
    s = s[(s.index >= day0) & (s.index <= day1)][["open", "high", "low", "close"]].rename(columns=dict(open="o", high="h", low="l", close="c"))
    o = c[c.sym.str.startswith(".SPXW")].copy(); o["base"] = o.sym.str.split("{").str[0]; o["t"] = _t(o.ts_ms)
    o = o[(o.t >= day0) & (o.t <= day1) & (o.volume > 0)].merge(lg.rename(columns={"sym": "base"}), on="base")
    o[["bidv", "askv"]] = o[["bidv", "askv"]].fillna(0)
    S = s.c.reindex(o.t.values, method="ffill").values
    T = np.maximum((pd.Timestamp("2026-11-04 16:00") - o.t).dt.total_seconds().values / (365.25 * 86400), 1e-6)
    T = T + np.where(o.group.values == "1DTE", 1 / 365, 0)
    iv = o.iv.fillna(o.iv.median()).clip(0.05, 1.5).values
    d1 = (np.log(S / o.strike.values) + 0.5 * iv ** 2 * T) / (iv * np.sqrt(T))
    call = o.cp.values == 1
    o["dd"] = np.abs(np.where(call, ndtr(d1), ndtr(d1) - 1)) * 100 * S
    # prints: Lee-Ready side, single-leg flag
    pr = pr.copy(); pr["base"] = pr.sym.str.split("{").str[0]; pr["t"] = _t(pr.ts_ms)
    pr = pr[(pr.t >= day0) & (pr.t <= day1)]
    mid = (pr.bid + pr.ask) / 2
    side = np.where(pr.px >= pr.ask, 1, np.where(pr.px <= pr.bid, -1, np.sign(pr.px - mid)))
    pr["side"] = side
    first = pr.groupby("base").t.min()
    # SLE ratios: per contract and side, single-leg volume / all volume (need ≥ 30 contracts on the side)
    g = pr[pr.side != 0].groupby(["base", "side"])
    tot = g["size"].sum(); sl = pr[(pr.side != 0) & (~pr.spread)].groupby(["base", "side"])["size"].sum().reindex(tot.index).fillna(0)
    ratio = (sl / tot).where(tot >= 30)
    glob_ = (pr[(pr.side != 0) & (~pr.spread)].groupby(["side"])["size"].sum() / pr[pr.side != 0].groupby("side")["size"].sum())
    o["r_ask"] = o.base.map(ratio.xs(1, level="side")).fillna(glob_[1]).values
    o["r_bid"] = o.base.map(ratio.xs(-1, level="side")).fillna(glob_[-1]).values
    # HYB: single-leg prints (classified) from the first replayed print on, candle split before it
    o["first"] = o.base.map(first)
    o["cov"] = o.t >= o["first"].fillna(pd.Timestamp("2100-01-01"))
    slp = pr[(~pr.spread) & (pr.side != 0)].copy(); slp["m"] = slp.t.dt.floor("1min")
    pb = slp.assign(a=np.where(slp.side > 0, slp["size"], 0), b=np.where(slp.side < 0, slp["size"], 0)).groupby(["base", "m"])[["a", "b"]].sum()
    key = pd.MultiIndex.from_arrays([o.base, o.t.dt.floor("1min")])
    pa = pb.reindex(key).fillna(0)
    out = {}
    for ver in ("ALL", "HYB", "SLE"):
        if ver == "ALL": av, bv = o.askv.values, o.bidv.values
        elif ver == "SLE": av, bv = o.askv.values * o.r_ask.values, o.bidv.values * o.r_bid.values
        else:
            av = np.where(o["cov"], pa.a.values, o.askv.values); bv = np.where(o["cov"], pa.b.values, o.bidv.values)
        bull = np.where(call, av, bv) * o.dd.values; bear = np.where(call, bv, av) * o.dd.values
        for st in ("0DTE", "0+1DTE"):
            m = np.ones(len(o), bool) if st == "0+1DTE" else (o.group.values == "0DTE")
            f = pd.DataFrame(dict(b=bull[m], r=bear[m]), index=o.t.dt.floor("1min").values[m]).groupby(level=0).sum()
            bars = s.join(f).fillna({"b": 0.0, "r": 0.0})
            out[(ver, st, 1)] = bars
            g5 = bars.groupby(bars.index.floor("5min"))
            out[(ver, st, 5)] = pd.DataFrame(dict(o=g5.o.first(), h=g5.h.max(), l=g5.l.min(), c=g5.c.last(), b=g5.b.sum(), r=g5.r.sum()))
    cov = (o.volume * o["cov"]).sum() / o.volume.sum()
    return out, cov, float(glob_[1]), float(glob_[-1])


# ── engine ──────────────────────────────────────────────────────────────────────────────────────────────────────
@njit(cache=True)
def colour(net, tot, h, l, c, src, W, gate, rollbase, X, sticky, conf, CD, skip):
    n = len(c); col = np.zeros(n, np.int64); stk = 0; last = 0; g = 99
    for i in range(n):
        if src == 0:                                  # per bar
            v = net[i] / tot[i] if tot[i] > 0 else 0.0
            if rollbase:
                a = max(0, i - 30); sn = 0.0; st = 0.0
                for j in range(a, i): sn += net[j]; st += tot[j]
                if st > 0: v -= sn / st
            ok = True
            if gate > 0:
                if i < 10: ok = False
                else:
                    arr = np.sort(np.abs(net[:i])); k = (i - 1) * gate / 100.0; lo = int(np.floor(k)); hi = int(np.ceil(k))
                    ok = abs(net[i]) >= arr[lo] + (arr[hi] - arr[lo]) * (k - lo)
            if not ok: v = 0.0
        else:
            a = 0 if src == 2 else max(0, i - W + 1); sn = 0.0; st = 0.0
            for j in range(a, i + 1): sn += net[j]; st += tot[j]
            v = sn / st if st > 0 else 0.0
        if v >= X: s_ = 1
        elif v <= -X: s_ = -1
        else: s_ = 0
        if sticky:
            if s_ != 0: stk = s_
            w = stk
        else:
            w = s_
        if i < skip: w = 0
        if w != 0 and conf:
            if i < 2: w = 0
            elif w > 0 and not c[i] > max(h[i - 1], h[i - 2]): w = 0
            elif w < 0 and not c[i] < min(l[i - 1], l[i - 2]): w = 0
        if w != 0 and CD > 0 and last != 0 and w == -last and g < CD: w = 0
        col[i] = w
        if w != 0: g = 0; last = w
        else: g += 1
    return col


@njit(cache=True)
def trade(c, col, hold, cost):
    pos = 0; px = 0.0; pnl = 0.0; n = 0; wins = 0
    for i in range(len(c)):
        w = col[i]
        if i == len(c) - 1: w = 0; tgt = 0
        elif hold: tgt = pos if w == 0 else w
        else: tgt = w
        if tgt != pos:
            if pos != 0:
                r = (c[i] - px) * pos; pnl += r - cost; n += 1
                if r > 0: wins += 1
            pos = tgt; px = c[i]
    return pnl, n, wins


SRC = [("bar", 0, 0, 0, 0), ("bar gate60", 0, 0, 60, 0), ("bar base30", 0, 0, 0, 1), ("bar gate60 base30", 0, 0, 60, 1)] + \
      [(f"roll {w}m", 1, w, 0, 0) for w in (5, 10, 15, 20, 30, 45, 60)] + [("since open", 2, 0, 0, 0)]
XS = [0.01, 0.02, 0.03, 0.05, 0.08, 0.10, 0.12, 0.15, 0.20, 0.25]
GRID = list(itertools.product(range(len(SRC)), (0, 1), XS, (0, 1), (0, 3, 5, 10), (0, 10), (0, 1)))   # src, sticky, X, conf, CD, skip(min), hold


def run(bars, m):
    net = (bars.b - bars.r).values.astype(np.float64); tot = (bars.b + bars.r).values.astype(np.float64)
    h, l, c = bars.h.values.astype(float), bars.l.values.astype(float), bars.c.values.astype(float)
    res = np.zeros((len(GRID), 3))
    for k, (si, sticky, X, conf, CD, skip, hold) in enumerate(GRID):
        _, src, W, gate, rb = SRC[si]
        col = colour(net, tot, h, l, c, src, max(1, W // m), gate, rb, X, sticky, conf, CD, skip // m)
        res[k] = trade(c, col, hold, COST)
    return res


def label(k):
    si, sticky, X, conf, CD, skip, hold = GRID[k]
    return dict(lean=SRC[si][0], mode="sticky" if sticky else "band", X=X, confirm=bool(conf), cool=CD,
                skip10=bool(skip), grey="hold" if hold else "flat")


if __name__ == "__main__":
    nb, cov, ra, rb = nov4_bars()
    print(f"4 Nov: replay covers {cov:.0%} of option volume; single-leg share of volume: at ask {ra:.0%}, at bid {rb:.0%}")
    R4 = {}
    for key, bars in nb.items():
        R4[key] = run(bars, key[2])
    hist = pickle.load(open(f"{B}/l47/bars.pkl", "rb"))
    RH = {}
    for st in ("0DTE", "0+1DTE"):
        for m in (1, 5):
            days = sorted(d for (d, mm, f) in hist if mm == m and f == st and d != "2026-11-04" and len(hist[(d, mm, f)]) >= 20)
            per = np.stack([run(hist[(d, m, st)], m) for d in days])     # days × grid × 3
            RH[(st, m)] = (days, per)
    pickle.dump(dict(R4=R4, RH=RH, GRID=GRID, SRC=SRC, cov=cov, ra=ra, rb=rb), open(f"{B}/l48/results.pkl", "wb"))
    print("grid size", len(GRID), "done")
