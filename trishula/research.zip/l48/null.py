import pickle,numpy as np,pandas as pd
from grid import run, GRID
B="/tmp/claude-0/-home-claude/dee3bb00-9e12-54e5-970a-89cb0441116b/scratchpad"
A=pd.read_pickle('all.pkl')
hist=pickle.load(open(f"{B}/l47/bars.pkl","rb")); rng=np.random.default_rng(11)
# NULL: same flow, but each day's flow is circularly shifted by a random offset (keeps its texture, breaks timing vs price)
out={}
for st in ('0DTE',):
  for m in (1,5):
    days=sorted(d for (d,mm,f) in hist if mm==m and f==st and d!='2026-11-04' and len(hist[(d,mm,f)])>=20)
    per=[]
    for d in days:
        b=hist[(d,m,st)].copy(); k=rng.integers(len(b)//4,3*len(b)//4)
        b[['b','r']]=np.roll(b[['b','r']].values,k,axis=0); per.append(run(b,m))
    per=np.stack(per); h=len(days)//2; tot=per[:,:,0].sum(0)
    rob=((tot>0)&(per[:h,:,0].mean(0)>0)&(per[h:,:,0].mean(0)>0)&((per[:,:,0]>0).sum(0)>=14))
    real=A[(A.ver=='ALL')&(A.flow==st)&(A.bar==m)]
    rr=((real.hist_tot>0)&(real.h1>0)&(real.h2>0)&(real.hist_up>=14))
    print(f"{st} {m}-min: rules with history total>0 — REAL {np.mean(real.hist_tot>0):.0%}  vs  TIME-SHIFTED FLOW (no info) {np.mean(tot>0):.0%}   |  robust rules REAL {rr.sum()} vs NULL {rob.sum()}  | best total REAL {real.hist_tot.max():.0f} vs NULL {tot.max():.0f}")
both=A[A.ver=='SLE'].merge(A[A.ver=='ALL'][['flow','bar','lean','mode','X','confirm','cool','skip10','grey','hist_tot','h1','h2','hist_up']],on=['flow','bar','lean','mode','X','confirm','cool','skip10','grey'],suffixes=('','_a'))
ok=both[(both.nov4>0)&(both.hist_tot_a>0)&(both.h1_a>0)&(both.h2_a>0)&(both.hist_up_a>=13)]
print('\nrules positive on 4 Nov (single-leg est.) AND robust on 22 history days:',len(ok),'of',len(both))
print(ok.sort_values('hist_tot_a',ascending=False)[['flow','bar','lean','mode','X','confirm','cool','skip10','grey','nov4','n4','hist_tot_a','h1_a','h2_a','hist_up_a']].head(15).round(1).to_string(index=False))
