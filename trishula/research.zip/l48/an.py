import pickle,numpy as np,pandas as pd
exec(open('grid.py').read().split('if __name__')[0].split('# ── 4 Nov bars')[0])
from grid import GRID, SRC, label
D=pickle.load(open('results.pkl','rb')); R4=D['R4']; RH=D['RH']
L=pd.DataFrame([label(k) for k in range(len(GRID))])
pd.set_option('display.width',260); pd.set_option('display.max_columns',40)
rows=[]
for (ver,st,m),r in R4.items():
    d=L.copy(); d['ver']=ver; d['flow']=st; d['bar']=m; d['nov4']=r[:,0]; d['n4']=r[:,1]
    days,per=RH[(st,m)]
    d['hist_tot']=per[:,:,0].sum(0); d['hist_day']=per[:,:,0].mean(0); d['hist_up']=(per[:,:,0]>0).sum(0); d['hist_tr']=per[:,:,1].mean(0)
    h=len(days)//2; d['h1']=per[:h,:,0].mean(0); d['h2']=per[h:,:,0].mean(0)
    d['hist_t']=d.hist_day/(per[:,:,0].std(0)/np.sqrt(len(days))+1e-9)
    rows.append(d)
A=pd.concat(rows,ignore_index=True); A.to_pickle('all.pkl')
print('combinations evaluated:',len(A),' (',len(GRID),'rules × 3 flow versions × 0DTE/0+1DTE × 1/5-min )')
for ver in ('ALL','HYB','SLE'):
    a=A[A.ver==ver]; print(f"\n4 Nov {ver}: {np.mean(a.nov4>0):.0%} of rules profitable · median {a.nov4.median():+.1f} · best {a.nov4.max():+.1f}")
print('\nHISTORY (22 days, ALL flow): share of rules with total > 0:', f"{np.mean(A[A.ver=='ALL'].hist_tot>0):.0%}",
      ' · with total > 0 AND both halves > 0 AND ≥ 14/22 days up:', int(((A.ver=='ALL')&(A.hist_tot>0)&(A.h1>0)&(A.h2>0)&(A.hist_up>=14)).sum()))
cols=['flow','bar','lean','mode','X','confirm','cool','skip10','grey','nov4','n4','hist_tot','hist_day','hist_t','hist_up','hist_tr','h1','h2']
print('\nTOP 20 on 4 Nov, SLE (single-leg estimate) — and how the same rule did on 22 history days:')
print(A[A.ver=='SLE'].sort_values('nov4',ascending=False)[cols].head(20).round(2).to_string(index=False))
print('\nTOP 20 on 22 HISTORY days (ALL flow, robust: both halves > 0) — and their 4 Nov SLE result:')
H=A[(A.ver=='ALL')&(A.h1>0)&(A.h2>0)].sort_values('hist_t',ascending=False).head(20)
S=A[A.ver=='SLE'].set_index(['flow','bar','lean','mode','X','confirm','cool','skip10','grey'])
H=H.assign(nov4_SLE=S.loc[list(map(tuple,H[['flow','bar','lean','mode','X','confirm','cool','skip10','grey']].values))].nov4.values)
print(H[cols+['nov4_SLE']].round(2).to_string(index=False))
print('\nWHAT MATTERS — mean history total per option value (ALL flow, 1-min), and mean 4 Nov SLE:')
for k in ['lean','mode','X','confirm','cool','skip10','grey','flow','bar']:
    g=A[A.ver=='ALL'].groupby(k).hist_tot.mean().round(0); g2=A[A.ver=='SLE'].groupby(k).nov4.mean().round(1)
    print(f"  {k:8s} hist:",dict(g),"\n           4Nov SLE:",dict(g2))
