import sys, datetime as dt, numpy as np, pandas as pd
sys.path.insert(0,"/home/claude/trishula")
from core import terrain as T
exec(open("prof.py").read().split("spot=7596.75")[0])
spot=7596.75; exps=["2026-11-12","2026-11-13","2026-11-16"]
c0=chain(exps)
print("OI by expiry:", c0.groupby("exp").oi.sum().to_dict())
def show(c,label,signed=True,vw=0.05):
    pg,Z,taus=T.terrain_grid(c,spot,exps,now,day,greek="Gamma",weighting="OI + Volume",signed=signed,units="minis",p_min=7420,p_max=7780,n_time=6,vol_w=vw)
    for j,lab in ((0,"10:30"),(5,"~15:50")):
        col=-Z[:,j]; v=np.interp(np.arange(7430,7781,25),pg,col)
        print(f"{label:52s} {lab:6s} | {''.join('R' if x>3 else ('G' if x<-3 else '·') for x in v)} | spot {np.interp(spot,pg,col):+6.0f}")
show(c0,"naive all (calls+ / puts−), 3 exps",signed=False)
c=c0.copy(); naive=np.where(c.cp==1,1.0,-1.0)
c["dsign"]=np.where(c.exp=="2026-11-12",c.dsign,naive); show(c,"0DTE tape(all) + 1DTE/2DTE naive")
c["dsign"]=np.where(c.exp=="2026-11-12",c.dsign,naive*0.3); show(c,"0DTE tape(all) + 1DTE/2DTE naive×0.3")
