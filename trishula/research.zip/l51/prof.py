import sys, datetime as dt, numpy as np, pandas as pd
sys.path.insert(0,"/home/claude/trishula")
from core import terrain as T
D="../d1112"
T0=pd.Timestamp("2026-11-12 10:30",tz="America/New_York")
cs=pd.read_parquet(f"{D}/chain_snapshots.parquet")
p=pd.read_parquet(f"{D}/prints.parquet"); p=p[(p.ts_ms<=T0.value//10**6)&(p.valid)&(p.ev_type.astype(str)!="2")]
day=dt.date(2026,11,12); now=dt.datetime(2026,11,12,10,30)
def chain(exps):
    out=[]
    for e in exps:
        c=cs[(cs.exp==e)&(cs.ts_ms<=T0.value//10**6)]; c=c[c.ts_ms==c.ts_ms.max()].copy(); out.append(c)
    c=pd.concat(out); c["volume"]=c.day_volume; c["type"]=np.where(c.cp==1,"call","put"); return c
def ds(df):
    n=(df.aggr*df["size"]).groupby(df.sym).sum(); t=df["size"].groupby(df.sym).sum(); return -(n/t)
dsl=ds(p[~p.spread_leg]); dall=ds(p)
spot=7596.75
for exps in (["2026-11-12"],["2026-11-12","2026-11-13","2026-11-16"]):
    c0=chain(exps)
    for src,m in (("app (all prints, as recorded)",None),("single-leg",dsl),("all prints (recomputed)",dall),("FLIPPED app",-1)):
        c=c0.copy()
        if isinstance(m,pd.Series): c["dsign"]=c.sym.map(m)
        elif m==-1: c["dsign"]=-c.dsign
        for vw in (0.0,0.05,1.0):
            pg,Z,taus=T.terrain_grid(c,spot,exps,now,day,greek="Gamma",weighting="OI + Volume",signed=True,units="minis",p_min=7420,p_max=7780,n_time=6,vol_w=vw)
            col=-Z[:,0]   # HPT sign: + = dealers BUY per $1 (short gamma)
            lv=np.arange(7430,7781,25); v=np.interp(lv,pg,col)
            sgn="".join("R" if x>3 else ("G" if x<-3 else "·") for x in v)
            print(f"exps {len(exps)} {src:30s} vw {vw:4.2f} | 7430→7780 step 25: {sgn} | spot {np.interp(spot,pg,col):+6.0f}")
print("\nHIS 10:30 (read): 7430→7780 step 25:  R R R R R R R R(7605) R(7630) G(7655) G G G G G   [green above ~7650, red 7420–7640]")
