import pandas as pd, numpy as np
D="../d1112"
his={7630:-800,7625:1700,7620:400,7615:-200,7610:250,7605:-300,7600:780,7595:-280,7590:330,7585:340,7580:-900,7575:2070,7570:1220,7565:-1600,7560:-1860}
T=pd.Timestamp("2026-11-12 10:30",tz="America/New_York").value//10**6
cs=pd.read_parquet(f"{D}/chain_snapshots.parquet"); cs=cs[cs.exp=="2026-11-12"]
snap=cs[cs.ts_ms<=T].ts_ms.max(); c=cs[cs.ts_ms==snap].copy()
print("snapshot", pd.Timestamp(snap,unit="ms",tz="UTC").tz_convert("America/New_York"), "spot", c.spot.iloc[0])
p=pd.read_parquet(f"{D}/prints.parquet"); p=p[(p.exp=="2026-11-12")&(p.ts_ms<=T)&(p.valid)&(p.ev_type.astype(str)!="2")]
day0=pd.Timestamp("2026-11-12 09:30",tz="America/New_York").value//10**6
print("prints to 10:30:",len(p)," of which today RTH:",int((p.ts_ms>=day0).sum())," spread legs share",round(p.spread_leg.mean(),2), "src:",p.src.value_counts().to_dict())
def net(df):  # customer net contracts (+ = customer bought)
    return (df.aggr*df["size"]).groupby(df.sym).sum()
g=pd.DataFrame(index=c.sym)
g["strike"]=c.set_index("sym").strike; g["cp"]=c.set_index("sym").cp; g["oi"]=c.set_index("sym").oi; g["vol"]=c.set_index("sym").day_volume
g["dsign_app"]=c.set_index("sym").dsign
sl=p[~p.spread_leg]; 
for name,df in (("all_all",p),("sl_all",sl),("all_rth",p[p.ts_ms>=day0]),("sl_rth",sl[sl.ts_ms>=day0]),("sl_pre",sl[sl.ts_ms<day0])):
    g["cust_"+name]=net(df).reindex(g.index).fillna(0)
    tot=df["size"].groupby(df.sym).sum().reindex(g.index)
    g["ds_"+name]=(-g["cust_"+name]/tot).fillna(np.nan)
rows={}
for k in his:
    s=g[g.strike==k]; rows[k]=dict(his=his[k],
        app=(s.oi*s.dsign_app).sum(),                               # what Terrain uses (vw 0): OI × app dsign
        oi_sl=(s.oi*s.ds_sl_all).sum(), oi_slrth=(s.oi*s.ds_sl_rth).sum(),
        dealer_sl_rth=(-s.cust_sl_rth).sum(), dealer_all_rth=(-s.cust_all_rth).sum(), dealer_sl_pre=(-s.cust_sl_pre).sum(),
        calls_oi=s[s.cp==1].oi.sum(), puts_oi=s[s.cp==-1].oi.sum(),
        cust_call_sl_rth=s[s.cp==1].cust_sl_rth.sum(), cust_put_sl_rth=s[s.cp==-1].cust_sl_rth.sum())
R=pd.DataFrame(rows).T.round(0)
pd.set_option("display.width",250); print(R.to_string())
for col in ("app","oi_sl","oi_slrth","dealer_sl_rth","dealer_all_rth","dealer_sl_pre"):
    v=R[col].astype(float); print(f"{col:15s} corr with his {np.corrcoef(v,R.his)[0,1]:+.2f}   sign agree {np.mean(np.sign(v)==np.sign(R.his)):.0%}")
