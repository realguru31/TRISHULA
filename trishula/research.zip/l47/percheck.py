import pickle, numpy as np, pandas as pd, sys
sys.argv=['x']
src=open('lean_test.py').read(); exec(src.split('days = load_all()')[0])
cache=pickle.load(open('bars.pkl','rb'))
days=sorted({k[0] for k in cache})
cfgs=[(1,'0DTE',0.15,60,'none',False,3),(1,'0DTE',0.10,60,'roll',False,3),(1,'0DTE',0.15,60,'none',True,3),(1,'0DTE',0.06,0,'none',False,0),(5,'0DTE',0.06,0,'none',False,3)]
for cfg in cfgs:
    m,fl,L,P,base,cf,co=cfg; per=[]; allnov=[]; agree=[]
    for d in days:
        k=(d,m,fl)
        if k not in cache or len(cache[k])<20: continue
        b=cache[k]; col=paint(b,L,P,base,cf,co); c=b.c.values; s=int(20/m)
        # non-overlapping: take a switch only if >=20 min since last taken
        idx=[i for i in range(len(col)) if col[i]!=0 and (i==0 or col[i-1]!=col[i])]
        last=-99; v=[]
        for i in idx:
            if i-last>=s and i+s<len(c): v.append((c[i+s]-c[i])*col[i]); last=i
        per.append((d,np.mean(v) if v else np.nan,len(v))); allnov+=v
        dc=np.sign(np.diff(c,prepend=c[0])); nz=col!=0
        agree.append(np.mean(col[nz]==dc[nz]) if nz.any() else np.nan)
    P_=pd.DataFrame(per,columns=['day','pts20','n'])
    a=np.array(allnov)
    print(cfg,f"non-overlap n={len(a)} mean={a.mean():.2f} t={a.mean()/(a.std()/np.sqrt(len(a))):.2f} days+={int((P_.pts20>0).sum())}/{P_.pts20.notna().sum()} colour=same-bar-direction {np.nanmean(agree):.0%}")
    if cfg==cfgs[0]: print(P_.round(2).to_string(index=False))
