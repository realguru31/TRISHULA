import pickle,numpy as np,pandas as pd
exec(open('band.py').read().split('rows=[]')[0])
src=open('lean_test.py').read(); exec(src[src.index('def paint'):src.index('def tech')])
cache=pickle.load(open('bars.pkl','rb'))
def cooldown(col,CD):
    if not CD: return col
    out=col.copy(); last=0; g=99
    for i,w in enumerate(col):
        if w and last and w==-last and g<CD: w=0
        out[i]=w
        if w: g=0; last=w
        else: g+=1
    return out
COST=0.5   # ES round trip, pts (spread + fees)
def trades(c,col,t):
    """enter at the close of the bar where the colour changes; exit when it changes again (grey = flat); flat at 15:59."""
    tr=[]; pos=0; px=0; ent=None
    for i in range(len(c)):
        w=col[i] if i<len(c)-1 else 0
        if w!=pos:
            if pos: tr.append(((c[i]-px)*pos, i-ent))
            pos=w; px=c[i]; ent=i
    return tr
cfgs=[('your screen: roll 5m sticky 3% cool 10',dict(src='roll',win=5,X=.03,h=True,cd=10)),
      ('roll 30m band 3%',dict(src='roll',win=30,X=.03,h=False,cd=0)),
      ('roll 30m band 3% cool 3',dict(src='roll',win=30,X=.03,h=False,cd=3)),
      ('roll 15m sticky 5%',dict(src='roll',win=15,X=.05,h=True,cd=0)),
      ('roll 15m sticky 8%',dict(src='roll',win=15,X=.08,h=True,cd=0)),
      ('roll 30m sticky 5%',dict(src='roll',win=30,X=.05,h=True,cd=0)),
      ('since open band 2%',dict(src='open',win=0,X=.02,h=False,cd=0)),
      ('per bar 0.15 gate60 cool3 (first test best)',dict(src='bar'))]
rows=[]
for fl in ('0DTE','0+1DTE'):
  for name,p in cfgs:
    T=[];perday=[]
    for (d,m,f),b in sorted(cache.items()):
        if m!=1 or f!=fl or len(b)<60: continue
        c=b.c.values
        col=paint(b,0.15,60,'none',False,3) if p['src']=='bar' else cooldown(colour(run_lean(b,p['win']),p['X'],p['h']),p['cd'])
        col[:10]=0
        tr=trades(c,col,b.index); T+=tr; perday.append((d,sum(x for x,_ in tr),len(tr)))
    g=np.array([x for x,_ in T]); hold=np.array([h for _,h in T]); P=pd.DataFrame(perday,columns=['d','g','n'])
    net=P.g-COST*P.n
    rows.append(dict(flow=fl,rule=name,trades_day=P.n.mean(),hold_min=hold.mean(),win=(g>0).mean(),avg_win=g[g>0].mean(),avg_loss=g[g<0].mean(),
        gross_day=P.g.mean(),net_day=net.mean(),net_total=net.sum(),days_up=f"{(net>0).sum()}/{len(net)}",
        worst_day=net.min(),best_day=net.max(),h1=net[:len(net)//2].mean(),h2=net[len(net)//2:].mean(),t=net.mean()/(net.std()/np.sqrt(len(net)))))
R=pd.DataFrame(rows); pd.set_option('display.width',300); R.to_csv('pnl.csv',index=False)
print(R.round(2).to_string(index=False))
# equity curve for the best + your screen
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(12,5))
for name,p in cfgs[:6]:
    eq=[0]
    for (d,m,f),b in sorted(cache.items()):
        if m!=1 or f!='0DTE' or len(b)<60: continue
        c=b.c.values; col=cooldown(colour(run_lean(b,p['win']),p['X'],p['h']),p['cd']); col[:10]=0
        tr=trades(c,col,b.index); eq.append(eq[-1]+sum(x for x,_ in tr)-COST*len(tr))
    ax.plot(eq,label=name,lw=2.2 if 'screen' in name else 1.4)
ax.axhline(0,color='k',lw=.6); ax.set_ylabel('cumulative SPX pts, after 0.5 pt/round trip'); ax.set_xlabel('session (24 Sep → 23 Oct)')
ax.set_title('Execute at every colour change (long blue / short magenta / flat grey) — 1-min, 0DTE lean, 22 sessions',loc='left',fontsize=10)
ax.legend(fontsize=8); ax.grid(alpha=.2); fig.tight_layout(); fig.savefig('equity.png',dpi=110)
