import pickle, numpy as np, pandas as pd
src=open('lean_test.py').read(); exec(src.split('days = load_all()')[0])
cache=pickle.load(open('bars.pkl','rb'))
for m in (1,5):
  for L in (0.06,0.10,0.15):
   for P in (0,60):
    out={10:[],20:[],30:[]}; perday=[]
    for k,b in cache.items():
        if k[1]!=m or k[2]!='0DTE' or len(b)<20: continue
        col=paint(b,L,P,'none',False,0); c=b.c.values; dc=np.sign(np.diff(c,prepend=c[0])) if m==1 else np.sign(c-b.o.values)
        idx=[i for i in range(len(c)) if col[i]!=0 and col[i]==-dc[i]]
        last=-99; v=[]
        for i in idx:
            if i-last<int(20/m): continue
            last=i
            for h in out:
                s=int(h/m)
                if i+s<len(c): out[h].append((c[i+s]-c[i])*col[i])
            if i+int(20/m)<len(c): v.append((c[i+int(20/m)]-c[i])*col[i])
        if v: perday.append(np.mean(v))
    r={h:(np.mean(a),np.mean(a)/(np.std(a)/np.sqrt(len(a)))) for h,a in out.items()}
    print(m,L,P,'n',len(out[20]),' '.join(f"{h}m {r[h][0]:+.2f}(t{r[h][1]:+.1f})" for h in r),'days+',sum(np.array(perday)>0),'/',len(perday))
