import pickle,numpy as np,pandas as pd
exec(open('pnl.py').read().split('cfgs=[')[0])
def view_colour(b,win,X,conf,CD,skip):
    rl=run_lean(b,win); h,l,c=b.h.values,b.l.values,b.c.values; col=np.zeros(len(c),int); stk=0;last=0;g=99
    for i in range(len(c)):
        v=rl[i]
        if v>=X: stk=1
        elif v<=-X: stk=-1
        w=stk if i>=skip else 0
        if w and conf:
            if i<2: w=0
            elif w>0 and not c[i]>max(h[i-1],h[i-2]): w=0
            elif w<0 and not c[i]<min(l[i-1],l[i-2]): w=0
        if w and CD and last and w==-last and g<CD: w=0
        col[i]=w
        if w: g=0;last=w
        else: g+=1
    return col
def sar(c,col):   # first blue close → long, first magenta close → short; grey = keep position; flat at end
    pos=0;px=0;tr=[]
    for i in range(len(c)):
        if col[i] and col[i]!=pos:
            if pos: tr.append((c[i]-px)*pos)
            pos=col[i];px=c[i]
    if pos: tr.append((c[-1]-px)*pos)
    return tr
for label,skip in (('as on screen (colours from 09:30)',0),('ignore first 10 min',10)):
  for conf in (True,False):
    net=[];n=0;rows=[]
    for (d,m,f),b in sorted(cache.items()):
        if m!=1 or f!='0DTE' or len(b)<60: continue
        tr=sar(b.c.values,view_colour(b,15,0.08,conf,10,skip)); v=sum(tr)-COST*len(tr); net.append(v); n+=len(tr); rows.append((d,round(v,1),len(tr)))
    net=np.array(net)
    print(f"{label:34s} confirm={conf!s:5s}: total {net.sum():+.0f} pts · {net.mean():+.1f}/day · {n/len(net):.1f} trades/day · {sum(net>0)}/{len(net)} days up · halves {net[:11].mean():+.1f} / {net[11:].mean():+.1f} · worst {net.min():+.0f}")
    if skip==0 and conf: print('   ',rows)
