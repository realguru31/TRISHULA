import pickle,numpy as np,pandas as pd
exec(open('band.py').read().split('rows=[]')[0])
cache=pickle.load(open('bars.pkl','rb'))
# entries = price breakouts (close beyond the prior 15-min high/low, first bar of the break); split by lean colour
for win,X,h in ((15,0.05,True),(15,0.08,True),(30,0.03,False),(30,0.05,True)):
  res={'with':{10:[],20:[],30:[]},'against':{10:[],20:[],30:[]},'grey':{10:[],20:[],30:[]}}
  for (d,m,f),b in cache.items():
    if m!=1 or f!='0DTE' or len(b)<60: continue
    c=b.c.values; col=colour(run_lean(b,win),X,h); col[:10]=0
    hi=pd.Series(c).rolling(15).max().shift(1).values; lo=pd.Series(c).rolling(15).min().shift(1).values
    sig=np.where(c>hi,1,np.where(c<lo,-1,0)); last=-99
    for i in range(16,len(c)):
        if sig[i]==0 or sig[i-1]==sig[i] or i-last<10: continue
        last=i; k='grey' if col[i]==0 else ('with' if col[i]==sig[i] else 'against')
        for hz in (10,20,30):
            if i+hz<len(c): res[k][hz].append((c[i+hz]-c[i])*sig[i])
  print(f"lean {win}m X {X} {'sticky' if h else 'band'}")
  for k,v in res.items():
    a=np.array(v[20]); print(f"   breakout {k:8s} n {len(a):4d}  10m {np.mean(v[10]):+.2f}  20m {a.mean():+.2f} (t {a.mean()/(a.std()/np.sqrt(len(a))):+.1f})  30m {np.mean(v[30]):+.2f}  hit20 {np.mean(a>0):.0%}")
