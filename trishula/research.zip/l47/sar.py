import pickle,numpy as np,pandas as pd
exec(open('pnl.py').read().split('cfgs=[')[0])
out={}
for win in (5,10,15,20,30,45,60):
  for X in (0.03,0.05,0.08,0.10,0.12,0.15):
    net=[];n=0
    for (d,m,f),b in sorted(cache.items()):
        if m!=1 or f!='0DTE' or len(b)<60: continue
        c=b.c.values; col=colour(run_lean(b,win),X,True); col[:10]=0
        tr=trades(c,col,b.index); net.append(sum(x for x,_ in tr)-COST*len(tr)); n+=len(tr)
    out[(win,X)]=(np.sum(net),n/len(net),sum(np.array(net)>0))
T=pd.Series({k:v[0] for k,v in out.items()}).unstack().round(0)
N=pd.Series({k:v[1] for k,v in out.items()}).unstack().round(1)
D=pd.Series({k:v[2] for k,v in out.items()}).unstack()
print("TOTAL net SPX pts over 22 days (rows = rolling window min, cols = X)"); print(T)
print("\ntrades/day"); print(N); print("\ndays up /22"); print(D)
