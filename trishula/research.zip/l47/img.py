import pickle, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
src=open('lean_test.py').read(); exec(src.split('days = load_all()')[0])
cache=pickle.load(open('bars.pkl','rb'))
CM={1:'#1e90ff',-1:'#e0218a',0:'#9a9a9a'}
rules=[('Raw, noise 0.06 (no gate)',(0.06,0,'none',False,0)),
       ('Best in test: noise 0.15 + size gate 60th pct + 3-bar cooldown',(0.15,60,'none',False,3)),
       ('Same + your 2-bar high/low break',(0.15,60,'none',True,3))]
def draw(day,m,fn):
    b=cache[(day,m,'0DTE')]; fig,ax=plt.subplots(3,1,figsize=(15,10),sharex=True)
    x=np.arange(len(b))
    for a,(t,r) in zip(ax,rules):
        col=paint(b,*r); c=b.c.values
        if m==1:
            for i in range(1,len(c)): a.plot([i-1,i],[c[i-1],c[i]],color=CM[col[i]],lw=2.2 if col[i] else 1)
        else:
            for i in range(len(c)):
                a.plot([i,i],[b.l.values[i],b.h.values[i]],color=CM[col[i]],lw=1)
                a.add_patch(plt.Rectangle((i-.35,min(b.o.values[i],c[i])),.7,max(abs(c[i]-b.o.values[i]),.3),color=CM[col[i]]))
        sw=[i for i in range(len(col)) if col[i] and (i==0 or col[i-1]!=col[i])]
        for i in sw: a.scatter(i,c[i]+(1.5 if col[i]>0 else -1.5)*(1 if m==5 else .6),marker='^' if col[i]>0 else 'v',color=CM[col[i]],s=30,zorder=5)
        a.set_title(f"{t}   — {len(sw)} colour switches",loc='left',fontsize=10); a.grid(alpha=.2)
    tk=list(range(0,len(b),30 if m==1 else 6)); ax[-1].set_xticks(tk); ax[-1].set_xticklabels([b.index[i].strftime('%H:%M') for i in tk])
    fig.suptitle(f"SPX {day} — {m}-min, 0DTE delta-$ lean   (blue = bull flow, magenta = bear flow, grey = noise)",x=.01,ha='left',fontsize=12)
    fig.tight_layout(); fig.savefig(fn,dpi=110); plt.close(fig)
draw('2026-10-01',1,'day_good_1001.png'); draw('2026-10-14',1,'day_bad_1014.png'); draw('2026-11-04',5,'day_nov4_5m.png')
# summary
G=pd.read_csv('grid.csv'); C=pd.read_csv('controls.csv')
fig,ax=plt.subplots(1,2,figsize=(15,5))
for m,a in zip((1,5),ax):
    g=G[(G.bar==m)&(G.n_switch>=40)]
    lab=g.apply(lambda r:('confirm' if r.confirm else 'no confirm')+(' + cool' if r.cool else ''),axis=1)
    for i,(k,gg) in enumerate(g.groupby(lab)):
        a.scatter(np.full(len(gg),i)+np.random.uniform(-.15,.15,len(gg)),gg.t20,s=14,alpha=.7)
    ks=sorted(lab.unique()); a.set_xticks(range(len(ks))); a.set_xticklabels(ks)
    for rule,ls in (('TECH 2-bar break only','--'),('RANDOM',':')):
        v=C[(C.bar==m)&(C.rule==rule)].t20.values[0]; a.axhline(v,ls=ls,color='k',lw=1); a.text(len(ks)-.5,v,rule,fontsize=8,va='bottom',ha='right')
    a.axhline(2,color='r',lw=.6); a.axhline(-2,color='r',lw=.6)
    a.set_title(f"{m}-min bars: every setting tested, t-stat of SPX 20 min after a colour switch",loc='left',fontsize=10); a.set_ylabel('t-stat (|t|>2 = noteworthy, before multiple-test penalty)')
fig.tight_layout(); fig.savefig('summary_grid.png',dpi=110)
