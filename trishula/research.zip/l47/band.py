import pickle, numpy as np, pandas as pd
cache=pickle.load(open('bars.pkl','rb'))
def run_lean(b,win):
    net=(b.b-b.r).values; tot=(b.b+b.r).values
    if win==0: cn,ct=np.cumsum(net),np.cumsum(tot)
    else: cn=pd.Series(net).rolling(win,min_periods=1).sum().values; ct=pd.Series(tot).rolling(win,min_periods=1).sum().values
    return np.where(ct>0,cn/np.where(ct>0,ct,1),0)
def colour(rl,X,hyst):
    col=np.zeros(len(rl),int); s=0
    for i,v in enumerate(rl):
        if hyst:   # stay in colour until the OTHER side of the band is crossed
            if v>=X: s=1
            elif v<=-X: s=-1
        else: s=1 if v>=X else (-1 if v<=-X else 0)
        col[i]=s
    return col
rows=[]
for fl in ('0DTE','0+1DTE'):
 for win in (0,15,30,60):
  for X in (0.01,0.02,0.03,0.05,0.08,0.12):
   for hyst in (False,True):
    pnl=[];sw={10:[],20:[],30:[]};days=[];flips=[];timein=[]
    for (d,m,f),b in cache.items():
        if m!=1 or f!=fl or len(b)<60: continue
        rl=run_lean(b,win); col=colour(rl,X,hyst); c=b.c.values
        col[:10]=0                      # first 10 min: too little flow
        dp=np.diff(c,append=c[-1]); p=(col*dp).sum()   # long blue / short magenta / flat grey, 1-bar later
        # position held from bar i close to i+1 close -> causal
        pnl.append(p); days.append(p>0); timein.append((col!=0).mean())
        idx=[i for i in range(1,len(col)) if col[i]!=0 and col[i]!=col[i-1]]; flips.append(len(idx))
        for k in sw: sw[k]+=[(c[i+k]-c[i])*col[i] for i in idx if i+k<len(c)]
    pnl=np.array(pnl)
    rows.append(dict(flow=fl,win=('since open' if win==0 else f'{win}m'),X=X,hyst=hyst,flips_day=np.mean(flips),
        time_coloured=np.mean(timein),pts_day=pnl.mean(),t_day=pnl.mean()/(pnl.std()/np.sqrt(len(pnl))),days_up=f"{sum(days)}/{len(days)}",
        sw20=np.mean(sw[20]) if sw[20] else np.nan,n_sw=len(sw[20]),h1=pnl[:len(pnl)//2].mean(),h2=pnl[len(pnl)//2:].mean()))
R=pd.DataFrame(rows); R.to_csv('band_grid.csv',index=False)
# controls: always long; price-momentum colour (sign of 30m SPX change)
al=[];mo=[]
for (d,m,f),b in cache.items():
    if m!=1 or f!='0DTE' or len(b)<60: continue
    c=b.c.values; dp=np.diff(c,append=c[-1]); al.append(dp[10:].sum())
    s=np.sign(c-np.r_[np.full(30,c[0]),c[:-30]]); s[:10]=0; mo.append((s*dp).sum())
pd.set_option('display.width',250)
print('controls pts/day: always long %.2f | 30m price momentum %.2f (t %.2f)'%(np.mean(al),np.mean(mo),np.mean(mo)/(np.std(mo)/np.sqrt(len(mo)))))
print(R.sort_values('t_day',ascending=False).head(15).round(2).to_string(index=False))
print('\nworst 5'); print(R.sort_values('t_day').head(5).round(2).to_string(index=False))
print('\nby window (mean t_day):'); print(R.groupby(['win','hyst']).t_day.mean().round(2).unstack())
