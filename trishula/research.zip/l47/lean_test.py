"""L47 — LEAN CANDLES: does painting SPX candles by options-flow lean help a trader?
Data: 22 history sessions (24 Sep – 21 Oct, 1-min option candles with bid/ask volume, 0DTE (+1DTE where pulled)) + 4 Nov.
Flow = candle bid/ask split (all prints — single-leg needs prints, which the history does not have), weighted in delta $
(Black-Scholes delta with a flat 14 % IV: only the WEIGHTING of contracts, not a pricing model).
Rules tested (state machine, causal, bar by bar):
  raw      colour = sign(lean − baseline) when |lean − baseline| ≥ L and the size gate passes, else grey
  confirm  a NEW colour only if the bar closes beyond the prior 2 bars' high (blue) / low (magenta)
  cool     after a coloured state, ≥ N grey bars before the opposite colour may appear
Controls: TECH-only (the 2-bar break with no flow at all) and RANDOM bars.
Score: at each switch INTO blue / magenta (the moment a trader would act), SPX points 10/20/30 min later, signed by the
colour; plus DIVERGENCE bars (candle one way, flow the other). Reported overall, first half vs second half of days."""
import sys, glob, json, pickle, itertools
sys.path.insert(0, "/home/claude/trishula/research/l28")
import numpy as np, pandas as pd, warnings
from scipy.special import ndtr
warnings.filterwarnings("ignore")
B = "/tmp/claude-0/-home-claude/dee3bb00-9e12-54e5-970a-89cb0441116b/scratchpad"
_src = open("/home/claude/trishula/research/l28/l29.py").read().split("def cool(")[0]
_src = _src.replace("from setup import wings, setup_signals", "").replace("from core import dtv2 as V", "")
exec(_src)


def nov4():
    c = pd.read_pickle(f"{B}/lean2/data/candles.pkl"); lg = pd.read_pickle(f"{B}/lean2/data/legs.pkl")
    o = c[c.sym.str.startswith(".SPXW")].copy(); o["base"] = o.sym.str.split("{").str[0]
    o = o.merge(lg[["sym", "exp", "strike", "cp"]], left_on="base", right_on="sym", suffixes=("_x", ""))
    o["t"] = _t(o.ts_ms); o[["bidv", "askv", "volume"]] = o[["bidv", "askv", "volume"]].fillna(0)
    s = c[c.sym.str.startswith("SPX{")].drop_duplicates("ts_ms")
    S = pd.Series(s.close.values, index=_t(s.ts_ms).values).sort_index()
    rth = pd.date_range("2026-11-04 09:30", "2026-11-04 15:55", freq="5min")
    return dict(day="2026-11-04", S=S.reindex(rth).ffill(), rth=rth, o=o[["t", "base", "exp", "strike", "cp", "volume", "bidv", "askv", "close"]], five=True)


def flow_bars(x, minutes, sets):
    """per bar: SPX o/h/l/c (from 1-min closes) + bull/bear delta $ for the chosen expiry set."""
    S = x["S"].dropna()
    g = S.groupby(S.index.floor(f"{minutes}min"))
    bars = pd.DataFrame(dict(o=g.first(), h=g.max(), l=g.min(), c=g.last()))
    o = x["o"]; o = o[(o.t >= x["rth"][0]) & (o.t <= x["rth"][-1]) & (o.volume > 0)]
    if sets == "0DTE":
        o = o[o.exp.astype(str) == x["day"]]
    Sp = S.reindex(o.t.values, method="ffill").values
    T = np.maximum((pd.Timestamp(f"{x['day']} 16:00") - o.t).dt.total_seconds().values / (365.25 * 86400), 1e-6)
    T = T + np.where(o.exp.astype(str).values != x["day"], 1 / 365, 0)
    d1 = (np.log(Sp / o.strike.values) + 0.5 * 0.14 ** 2 * T) / (0.14 * np.sqrt(T))
    delta = np.abs(np.where(o.cp.values == 1, ndtr(d1), ndtr(d1) - 1))
    dd = delta * 100 * Sp
    call = o.cp.values == 1
    bull = np.where(call, o.askv, o.bidv) * dd; bear = np.where(call, o.bidv, o.askv) * dd
    f = pd.DataFrame(dict(b=bull, r=bear), index=o.t.dt.floor(f"{minutes}min").values).groupby(level=0).sum()
    bars = bars.join(f).fillna(0.0)
    return bars[bars.index <= pd.Timestamp(f"{x['day']} 15:59")]


def paint(bars, L, P, base, confirm, cool):
    net, tot = (bars.b - bars.r).values, (bars.b + bars.r).values
    lean = np.where(tot > 0, net / np.where(tot > 0, tot, 1), 0)
    n = len(bars); col = np.zeros(n, int); state, grey_run, last = 0, 99, 0
    h, l, c = bars.h.values, bars.l.values, bars.c.values
    for i in range(n):
        b = 0.0
        if base == "roll" and i > 0:
            a = max(0, i - 30); st = tot[a:i].sum(); b = net[a:i].sum() / st if st > 0 else 0
        ok = True
        if P > 0:
            ok = i >= 10 and abs(net[i]) >= np.percentile(np.abs(net[:i]), P)
        e = lean[i] - b
        want = 1 if (ok and e >= L) else (-1 if (ok and e <= -L) else 0)
        if want != 0 and confirm and i >= 2:
            if want == 1 and not c[i] > max(h[i - 2], h[i - 1]): want = 0
            if want == -1 and not c[i] < min(l[i - 2], l[i - 1]): want = 0
        elif want != 0 and confirm:
            want = 0
        if want != 0 and cool and last != 0 and want == -last and grey_run < cool:
            want = 0
        col[i] = want
        if want == 0: grey_run += 1
        else: grey_run, last = 0, want
    return col


def tech(bars):
    h, l, c = bars.h.values, bars.l.values, bars.c.values; col = np.zeros(len(c), int)
    for i in range(2, len(c)):
        col[i] = 1 if c[i] > max(h[i - 2], h[i - 1]) else (-1 if c[i] < min(l[i - 2], l[i - 1]) else 0)
    return col


def score(bars, col, minutes, mode="switch"):
    c = bars.c.values; up = np.sign(bars.c.values - bars.o.values); out = {}
    if mode == "switch":
        idx = [i for i in range(len(col)) if col[i] != 0 and (i == 0 or col[i - 1] != col[i])]
        sgn = {i: col[i] for i in idx}
    elif mode == "diverge":
        idx = [i for i in range(len(col)) if col[i] != 0 and col[i] == -up[i]]
        sgn = {i: col[i] for i in idx}
    for k in (10, 20, 30):
        s = int(k / minutes)
        out[k] = [(c[i + s] - c[i]) * sgn[i] for i in idx if i + s < len(c)]
    return out


days = load_all() + [nov4()]
print(len(days), "days:", days[0]["day"], "…", days[-1]["day"])
grid = list(itertools.product([1, 5], ["0DTE", "0+1DTE"], [0.03, 0.06, 0.10, 0.15], [0, 60],
                              ["none", "roll"], [False, True], [0, 3]))
cache = {}
rows = []
half = len(days) // 2
for minutes, sets, L, P, base, conf, cool_ in grid:
    acc = {k: [[], []] for k in (10, 20, 30)}; dv = {k: [[], []] for k in (10, 20, 30)}; nsw = 0
    for di, x in enumerate(days):
        if x.get("five") and minutes == 1:
            continue
        key = (x["day"], minutes, sets)
        if key not in cache:
            cache[key] = flow_bars(x, minutes, sets)
        bars = cache[key]
        if len(bars) < 20: continue
        col = paint(bars, L, P, base, conf, cool_)
        sw, d_ = score(bars, col, minutes), score(bars, col, minutes, "diverge")
        for k in sw:
            acc[k][di >= half] += sw[k]; dv[k][di >= half] += d_[k]
        nsw += len(sw[10])
    r = dict(bar=minutes, flow=sets, L=L, P=P, base=base, confirm=conf, cool=cool_, n_switch=nsw)
    for k in (10, 20, 30):
        a = acc[k][0] + acc[k][1]
        r[f"sw{k}"] = np.mean(a) if a else np.nan
        r[f"t{k}"] = np.mean(a) / (np.std(a) / np.sqrt(len(a))) if len(a) > 5 else np.nan
        r[f"h1_{k}"] = np.mean(acc[k][0]) if acc[k][0] else np.nan; r[f"h2_{k}"] = np.mean(acc[k][1]) if acc[k][1] else np.nan
        dd_ = dv[k][0] + dv[k][1]; r[f"div{k}"] = np.mean(dd_) if dd_ else np.nan; r[f"ndiv"] = len(dv[10][0] + dv[10][1])
    rows.append(r)
R = pd.DataFrame(rows)
# controls
ctrl = []
rng = np.random.default_rng(3)
for minutes in (1, 5):
    tt = {k: [] for k in (10, 20, 30)}; rr = {k: [] for k in (10, 20, 30)}
    for x in days:
        if x.get("five") and minutes == 1: continue
        bars = cache[(x["day"], minutes, "0DTE")]
        col = tech(bars); sw = score(bars, col, minutes)
        for k in sw: tt[k] += sw[k]
        rc = np.zeros(len(bars), int); m = rng.choice(len(bars), size=max(1, len(bars) // 6), replace=False)
        rc[m] = rng.choice([-1, 1], size=len(m)); sr = score(bars, rc, minutes)
        for k in sr: rr[k] += sr[k]
    for name, d in (("TECH 2-bar break only", tt), ("RANDOM", rr)):
        ctrl.append(dict(bar=minutes, rule=name, n=len(d[10]), **{f"sw{k}": np.mean(d[k]) for k in d},
                         **{f"t{k}": np.mean(d[k]) / (np.std(d[k]) / np.sqrt(len(d[k]))) for k in d}))
C = pd.DataFrame(ctrl)
R.to_csv(f"{B}/l47/grid.csv", index=False); C.to_csv(f"{B}/l47/controls.csv", index=False)
pickle.dump(cache, open(f"{B}/l47/bars.pkl", "wb"))
pd.set_option("display.width", 250)
print(C.round(2).to_string(index=False))
cols = ["bar", "flow", "L", "P", "base", "confirm", "cool", "n_switch", "sw10", "t10", "sw20", "t20", "sw30", "t30", "h1_20", "h2_20", "ndiv", "div20"]
print("\nTOP 15 by t20 (n_switch ≥ 40):")
print(R[R.n_switch >= 40].sort_values("t20", ascending=False)[cols].head(15).round(2).to_string(index=False))
print("\nBOTTOM 8 by t20:")
print(R[R.n_switch >= 40].sort_values("t20")[cols].head(8).round(2).to_string(index=False))
print("\nmean over the whole grid by confirm × cool (t20):")
print(R[R.n_switch >= 40].groupby(["bar", "confirm", "cool"])[["sw20", "t20", "n_switch", "div20"]].mean().round(2))
