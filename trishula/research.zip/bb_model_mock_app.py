import sys
sys.path.insert(0,"/tmp/claude-0/-home-claude/dee3bb00-9e12-54e5-970a-89cb0441116b/scratchpad/l54"); sys.path.insert(0,"/tmp/claude-0/-home-claude/dee3bb00-9e12-54e5-970a-89cb0441116b/scratchpad/mock301/trishula")
import numpy as np, pandas as pd, streamlit as st, time
from scipy.stats import norm
st.set_page_config(layout="wide")
from fake import Rec
sys.path.insert(0,"/tmp/claude-0/-home-claude/dee3bb00-9e12-54e5-970a-89cb0441116b/scratchpad/mock301/trishula")
for _m in [m for m in list(sys.modules) if m == "core" or m.startswith("core.") or m == "tabs" or m.startswith("tabs.")]: del sys.modules[_m]
from core import bb as BB, edge_model as EM
from tabs import spxbb
def fake_hist():
    rng=np.random.default_rng(3); idx=pd.bdate_range("1990-01-02","2026-11-13"); n=len(idx)
    vix=np.empty(n); v=16.0
    for i in range(n): v=np.clip(v+0.08*(17-v)+rng.normal(0,1.2),9,80); vix[i]=v
    sig=vix/100/np.sqrt(252)
    r=rng.standard_t(4,n)*sig*0.75; c=350*np.exp(np.cumsum(r)); c=c/c[-1]*7539.77
    o=c*np.exp(rng.normal(0,0.3,n)*sig); hi=np.maximum(o,c)*np.exp(np.abs(rng.normal(0,0.6,n))*sig); lo=np.minimum(o,c)*np.exp(-np.abs(rng.normal(0,0.7,n))*sig)
    vix[-1]=16.2
    return pd.DataFrame(dict(Open=o,High=hi,Low=lo,Close=c,vix=vix),index=idx)
EM.load_history=fake_hist
@st.cache_resource
def trk():
    r=Rec(); r.spot=7539.77; ms=int(time.time()*1000)
    for sym,(ex,k,cp) in r.bb_meta.items():
        d=(7539.77-k) if cp<0 else (k-7539.77)
        if d<=0: bid=round(abs(d)+20,2)
        elif cp<0: bid=0.05 if d<=900 else 0.0; bid=max(bid, np.floor(4000*np.exp(-d/62))/100*1) if d<900 else bid
        else: bid=0.05 if d<=420 else 0.0; bid=max(bid, np.floor(3000*np.exp(-d/40))/100) if d<420 else bid
        bid=round(np.floor(bid*20)/20,2) if bid>0.05 else bid
        r.quotes[sym]=(bid, bid+0.10, ms)
    t=BB.Tracker(r,"",""); t.send=lambda m: True; t.step()
    t.cfg["sold_call"]=7700.0; t.cfg["sold_put"]=7300.0; t.cfg["mode"]="1DTE"
    return t
spxbb.render(trk())
