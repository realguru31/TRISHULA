import sys; sys.path.insert(0,"/home/claude/trishula")
import pandas as pd, numpy as np
from core import book as B
exec(open("lv.py").read().split("rec=[]")[0])
rec=[]; rows_at={}
for ms,t in zip(snaps,st):
    if t<pd.Timestamp("2026-11-12 09:35"): continue
    ch=cs[cs.ts_ms==ms]; sp=ch.spot.iloc[0]; S=B.mid_straddle(ch,sp)
    rc=B.signed_book_rows(ch,sp,units="contracts"); rg=B.signed_book_rows(ch,sp,units="gex")
    g=guide(rc,rg,sp,S); g.update(t=t,spot=sp,S=S); rec.append(g); rows_at[t]=rc
G=pd.DataFrame(rec).set_index("t")
print(G.iloc[::12].round(1).to_string())
pd.to_pickle(dict(G=G,rows_at=rows_at),"g.pkl")
