import sys, json; sys.path.insert(0,"/home/claude/trishula")
import pandas as pd, numpy as np
from core import dealer as DL, signs as SG
from tabs import tastier as TT
D="../d1112b"; E="2026-11-12"
cs=pd.read_parquet(f"{D}/chain_snapshots.parquet"); c1=pd.read_parquet(f"{D}/opt1m_backfill.parquet")
pr=pd.read_parquet(f"{D}/prints.parquet"); c5=pd.read_parquet(f"{D}/candles5.parquet")
legs={k:tuple(v) for k,v in json.load(open(f"{D}/legs.json")).items()}
ch=cs[(cs.exp==E)&(cs.ts_ms==cs[cs.exp==E].ts_ms.max())]
ds=SG.dsign_table(pr,c5,legs,E,int(ch.ts_ms.iloc[0]))
print("seed_dsign coverage", ds.seed_dsign.notna().mean().round(2), "mean seed", ds.seed_dsign.mean().round(3), "mean live dsign", ds.dsign.mean().round(3))
lg=ch.drop(columns=["dsign"]).merge(ds[["sym","dsign","seed_dsign"]],on="sym",how="left").drop_duplicates("sym")[["sym","strike","cp","oi","iv","dsign","seed_dsign"]]
spx=pd.read_parquet(f"{D}/spx1m.parquet"); spx["t"]=pd.to_datetime(spx.ts_ms,unit="ms",utc=True).dt.tz_convert("America/New_York").dt.tz_localize(None)
t0=pd.Timestamp("2026-11-12 09:30"); t1=pd.Timestamp(c1.m.max())
bars=spx[spx.t>=t0].rename(columns=dict(open="o",high="h",low="l",close="c"))
spot=ch.spot.iloc[0]
for beta in (True,):
    s=DL.surfaces_strike(lg,c1,t0,t1,E,beta,spot-90,spot+90,bars.set_index("t")["c"])
    print("strikes",len(s["P"]),"pos share",(s["gamma"]>0).mean().round(2), "flip non-nan", np.isfinite([np.nan]).sum())
    for k in ("gamma","vanna","dgamma"):
        TT._surface_panel(s,k,bars,beta).write_image(f"v28_{k}.png",width=900,height=460)
