# TRISHULA — SPXO check (Colab). Paste your two tastytrade values below, run, send me the whole output.
# !pip -q install "tastytrade==13.2.3"
TT_CLIENT_SECRET = ""   # ← paste
TT_REFRESH_TOKEN = ""   # ← paste

import asyncio, collections, datetime as dt
from tastytrade import Session
from tastytrade.instruments import get_option_chain
from tastytrade.streamer import DXLinkStreamer
from tastytrade.dxfeed import Summary, Trade


async def main():
    sess = Session(TT_CLIENT_SECRET, TT_REFRESH_TOKEN)
    chain = await get_option_chain(sess, "SPX")
    today = dt.date.today()
    print("1) roots per expiry in the SPX chain, next 70 days")
    print(f"{'expiry':<11} {'dow':<4} {'root':<6} {'settle':<7} {'exp type':<14} {'stops':<26} {'n':>5}  example")
    spxo = []
    for d in sorted(chain):
        if (d - today).days > 70:
            continue
        g = collections.defaultdict(list)
        for o in chain[d]:
            g[(o.root_symbol, str(o.settlement_type), str(o.expiration_type))].append(o)
        for (root, st, et), os_ in sorted(g.items()):
            print(f"{d!s:<11} {d:%a} {root:<6} {st:<7} {et:<14} {str(os_[0].stops_trading_at):<26} {len(os_):>5}  "
                  f"{os_[0].symbol} | {os_[0].streamer_symbol}")
            if root == "SPXO":
                spxo += os_
    print("\nSPXO total contracts listed:", len(spxo))

    # 2) OI + day volume on near-the-money SPXO vs SPXW, same expiry
    async with DXLinkStreamer(sess) as s:
        await s.subscribe(Trade, ["SPX"])
        spot = float((await asyncio.wait_for(s.get_event(Trade), 10)).price)
        print(f"\n2) SPX {spot:,.2f} — OI / previous-day volume within ±2% of spot, per root and expiry")
        for d in sorted({o.expiration_date for o in spxo}):
            for root in ("SPXO", "SPXW", "SPX"):
                os_ = [o for o in chain[d] if o.root_symbol == root and abs(float(o.strike_price) / spot - 1) <= 0.02]
                if not os_:
                    continue
                syms = [o.streamer_symbol for o in os_]
                await s.subscribe(Summary, syms)
                got = {}
                try:
                    while len(got) < len(syms):
                        e = await asyncio.wait_for(s.get_event(Summary), 8)
                        if e.event_symbol in syms:
                            got[e.event_symbol] = e
                except asyncio.TimeoutError:
                    pass
                await s.unsubscribe(Summary, syms)
                oi = sum(float(e.open_interest or 0) for e in got.values())
                pv = sum(float(getattr(e, "prev_day_volume", 0) or 0) for e in got.values())
                print(f"  {d} {root:<5} contracts {len(syms):>4}  answered {len(got):>4}  OI {oi:>10,.0f}  prev-day vol {pv:>9,.0f}")


await main()   # Colab cell (top-level await); in a plain .py use asyncio.run(main())
