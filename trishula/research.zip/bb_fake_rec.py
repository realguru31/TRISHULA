import sys, time, datetime as dt, types
sys.path.insert(0,"/home/claude/trishula")
from core import bb as BB, state as ST
ST._cfg["token"]=""
class Rec:
    def __init__(s):
        s.all_exps=[dt.date(2026,11,16),dt.date(2026,11,17)]; s.legs={}; s.quotes={}; s.bb_meta={}
        for e in ("2026-11-16","2026-11-17"):
            for k in range(6800,8001,5):
                for cp in (1,-1): s.bb_meta[f"{e}{cp}{k}"]=(e,float(k),cp)
        s.spot=7560.0
    def spot_now(s): return s.spot,"spx"
    def set_edges(s,e,c,p):
        ms=int(time.time()*1000)
        for sym,(ex,k,cp) in s.bb_meta.items():
            if ex!=e: continue
            ok=(cp>0 and k<=c) or (cp<0 and k>=p)
            s.quotes[sym]=(0.05 if ok else 0.0, 0.10, ms)
