import sys, json, datetime as dt; sys.path.insert(0,"/home/claude/trishula")
import pandas as pd, numpy as np
from core import vs3d_data as D, book as B
cs=pd.read_parquet("../d1112b/chain_snapshots.parquet")
class R: pass
r=R(); r.ui_state={}; r.oi_log={}; r.chain_df=lambda: cs; r.ts_ms=None
day=dt.date(2026,11,12); e=["2026-11-12"]
lk=D.card_lock(r,e,day,None)
print(lk["locked_at"], lk["late"], lk["oi_check"], [(k,v) for k,v in D.level_list(lk["levels"])])
# stale simulation: previous-day log equal to today's OI → should skip until OI differs
r2=R(); r2.ui_state={}; r2.chain_df=lambda: cs; r2.ts_ms=None
c0=cs[(cs.exp=="2026-11-12")]; last=c0[c0.ts_ms==c0.ts_ms.max()]
r2.oi_log={"2026-11-11": dict(zip(last.sym,last.oi))}
print("stale case:", D.card_lock(r2,e,day,None), r2.ui_state.get("oistale_2026-11-12"), D.oi_stale_note(r2,day))
# stale only before 06:30: prev log = the 05:03 snapshot OI → 09:25 snapshot fresh
first=c0[c0.ts_ms==c0.ts_ms.min()]
r3=R(); r3.ui_state={}; r3.chain_df=lambda: cs; r3.ts_ms=None; r3.oi_log={"2026-11-11": dict(zip(first.sym,first.oi))}
l3=D.card_lock(r3,e,day,None); print("fresh case:", l3["locked_at"], l3["oi_check"])
print(json.dumps(lk["levels"], default=float)[:200])
