import pandas as pd, numpy as np, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
a=pd.read_pickle("lv.pkl"); b=pd.read_pickle("g.pkl")
R,spx,G,rows_at=a["R"],a["spx"],b["G"],b["rows_at"]
spx=spx[spx.t<=G.index.max()]
L=pd.Series(dict(c_up1=7565.,c_up2=7600.,c_dn1=7400.,c_bal=7465.))  # app key_levels_lines at 09:35, S0 38.25
his={7630:-800,7625:1700,7620:400,7615:-200,7610:250,7605:-300,7600:780,7595:-280,7590:330,7585:340,7580:-900,7575:2070,7570:1220,7565:-1600,7560:-1860}
BG="#0e1117"; FG="#d8dde6"; GRN="#2ecc71"; RED="#ff4d5e"; YEL="#f5c542"; CY="#3fd0d6"
plt.rcParams.update({"axes.facecolor":BG,"figure.facecolor":BG,"text.color":FG,"axes.labelcolor":FG,"xtick.color":FG,"ytick.color":FG,"axes.edgecolor":"#444","font.size":10})
fig=plt.figure(figsize=(16,11)); gs=fig.add_gridspec(2,2,height_ratios=[1.35,1],hspace=0.28,wspace=0.12)
ax=fig.add_subplot(gs[0,:])
ax.fill_between(G.index,G.spot-G.S,G.spot+G.S,color="#ffffff",alpha=0.05,step="post",label="spot ± 1× straddle (guide range)")
ax.plot(spx.t,spx.close,color=FG,lw=1.4,label="SPX")
for k,c,n in (("up1",RED,"UP1"),("up2",RED,"UP2"),("dn1",RED,"DN1"),("dn2",RED,"DN2"),("bal",GRN,"BAL")):
    ls="--" if k.endswith("2") else "-"
    ax.step(G.index,G[k],where="post",color=c,lw=1.6 if k!="bal" else 2.2,ls=ls,alpha=0.9,label=f"guide {n}" if k in("up1","bal","up2") else None)
for k,c,n in (("c_up1",YEL,"UP1"),("c_up2",YEL,"UP2"),("c_dn1",YEL,"DN1"),("c_bal",CY,"BAL")):
    v=L[k]
    if v==v and 7480<=v<=7680:
        ax.axhline(v,color=c,lw=1,ls=":",alpha=0.9); ax.text(spx.t.iloc[0],v+1.5,f"app lock {n} {v:.0f}",color=c,fontsize=9)
ax.text(spx.t.iloc[-1],7484,f"app lock DN1 {L.c_dn1:.0f} / BAL {L.c_bal:.0f} — off chart: app range = open 7551 ± 96 (2.5× S0) — UP1 7565 sat BELOW spot 7577 at the lock",color=CY,ha="right",fontsize=9)
ax.set_ylim(7480,7680); ax.set_title("12 Nov · SPX with Book levels: app 09:35 lock (dotted) vs guide rule on live spot (solid/dashed)",loc="left",fontsize=12)
ax.legend(loc="upper left",facecolor=BG,edgecolor="#444",fontsize=9,ncol=3); ax.grid(alpha=0.12)
import matplotlib.dates as md; ax.xaxis.set_major_formatter(md.DateFormatter("%H:%M"))
def bars(axb,t,title,show_his=False):
    tt=min(rows_at,key=lambda x:abs(x-pd.Timestamp(t))); r=rows_at[tt]; r=r[(r.strike>=7480)&(r.strike<=7680)]
    axb.barh(r.strike,r.signed_pct,height=3.6,color=np.where(r.signed_pct>0,GRN,RED),alpha=0.85,label="ours 0DTE (OI × tape sign)")
    if show_his:
        k=np.array(list(his)); v=np.array(list(his.values()))
        axb.scatter(v,k,marker="D",s=28,facecolor="none",edgecolor="#ffffff",lw=1.2,label="Dan's 0DTE positions 10:30",zorder=5)
    g=G.loc[tt]; axb.axhline(g.spot,color=FG,lw=1,ls="-",alpha=0.6); axb.text(axb.get_xlim()[1],g.spot,f" spot {g.spot:.0f}",color=FG,va="center",fontsize=8)
    for k,c in (("up1",RED),("dn1",RED),("bal",GRN)):
        if g[k]==g[k]: axb.axhline(g[k],color=c,lw=1.3,ls="--"); axb.text(axb.get_xlim()[0],g[k]+1.5,f"guide {k.upper()} {g[k]:.0f}",color=c,fontsize=8)
    axb.axhspan(g.spot-g.S,g.spot+g.S,color="#ffffff",alpha=0.05)
    axb.set_ylim(7480,7680); axb.axvline(0,color="#666",lw=0.8); axb.set_title(f"{tt:%H:%M} · dealer contracts by strike (green long, red short)",loc="left"); axb.grid(alpha=0.12)
    axb.legend(loc="lower right",facecolor=BG,edgecolor="#444",fontsize=8)
bars(fig.add_subplot(gs[1,0]),"2026-11-12 09:35","09:35")
bars(fig.add_subplot(gs[1,1]),"2026-11-12 10:30","10:30",True)
fig.savefig("book_levels_1112.png",dpi=110,bbox_inches="tight")
