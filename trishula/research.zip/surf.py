import sys; sys.path.insert(0,"/home/claude/trishula")
import pandas as pd, numpy as np
from core import dealer as DL
from tabs import tastier as TT
D="../d1112b"; E="2026-11-12"
cs=pd.read_parquet(f"{D}/chain_snapshots.parquet"); c1=pd.read_parquet(f"{D}/opt1m_backfill.parquet")
print(c1.columns.tolist(), c1.m.min(), c1.m.max(), len(c1))
ch=cs[(cs.exp==E)&(cs.ts_ms==cs[cs.exp==E].ts_ms.max())]
lg=ch.drop_duplicates("sym")[["sym","strike","cp","oi","iv","dsign"]]
spot=ch.spot.iloc[0]; half=60
c1=c1[c1.sym.isin(set(lg.sym))]
t0=pd.Timestamp("2026-11-12 09:30"); t1=pd.Timestamp(c1.m.max())
spx=pd.read_parquet(f"{D}/spx1m.parquet"); spx["t"]=pd.to_datetime(spx.ts_ms,unit="ms",utc=True).dt.tz_convert("America/New_York").dt.tz_localize(None)
bars=spx[(spx.t>=t0)].rename(columns=dict(open="o",high="h",low="l",close="c"))
for beta in (True,False):
    s=DL.surfaces_tape(lg,c1,t0,t1,E,beta,spot-half,spot+half)
    G=s["gamma"]; print("beta",beta,"spot",spot,"gamma range",np.nanmin(G),np.nanmax(G), "cols all-neg frac", np.mean((G<0).all(axis=0)), "all-pos", np.mean((G>0).all(axis=0)))
    print(" last col by price:", dict(zip(s["P"][::10].round(), (G[::10,-1]/1e9).round(3))))
    for k in ("vanna","gamma"):
        TT._surface_panel(s,k,bars,beta).write_image(f"{k}_{int(beta)}.png",width=900,height=460)
