import sys, datetime as dt
sys.path.insert(0,"/tmp/claude-0/-home-claude/dee3bb00-9e12-54e5-970a-89cb0441116b/scratchpad/l54"); sys.path.insert(0,"/home/claude/trishula")
import numpy as np, pandas as pd, streamlit as st
from fake import Rec
from core import bb as BB, edge_model as EM
from tabs import spxbb
CALLS = st.session_state.setdefault("_calls", [0])
def fake_hist():
    CALLS[0] += 1
    rng=np.random.default_rng(1); idx=pd.bdate_range("1990-01-02","2026-11-13")
    r=rng.standard_t(4,len(idx))*0.009; c=3000*np.exp(np.cumsum(r)); o=c*np.exp(rng.normal(0,0.002,len(idx)))
    hi=np.maximum(o,c)*np.exp(np.abs(rng.normal(0,0.006,len(idx)))); lo=np.minimum(o,c)*np.exp(-np.abs(rng.normal(0,0.007,len(idx))))
    vix=np.clip(15*np.exp(np.cumsum(rng.normal(0,0.05,len(idx)))*0.1+rng.normal(0,0.1,len(idx))),9,80)
    return pd.DataFrame(dict(Open=o,High=hi,Low=lo,Close=c,vix=vix),index=idx)
EM.load_history=fake_hist
@st.cache_resource
def trk():
    r=Rec()
    import time
    ms=int(time.time()*1000)
    for sym,(ex,k,cp) in r.bb_meta.items():
        d=abs(k-7560)
        r.quotes[sym]=(max(0.0, round(5*np.exp(-d/120),2)), round(5*np.exp(-d/120)+0.1,2), ms)
    t=BB.Tracker(r,"",""); t.send=lambda m: True; t.step()
    t.cfg["sold_call"]=7700.0; t.cfg["sold_put"]=7300.0
    return t
spxbb.render(trk())
st.write(f"CALLS={CALLS[0]}")
