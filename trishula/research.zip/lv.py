import sys; sys.path.insert(0,"/home/claude/trishula")
import pandas as pd, numpy as np
from core import book as B
D="../d1112b"; E="2026-11-12"
cs=pd.read_parquet(f"{D}/chain_snapshots.parquet"); cs=cs[cs.exp==E].copy()
cs["type"]=np.where(cs.cp==1,"call","put")
spx=pd.read_parquet(f"{D}/spx1m.parquet")
et=lambda ms: pd.to_datetime(ms,unit="ms",utc=True).dt.tz_convert("America/New_York").dt.tz_localize(None)
spx["t"]=et(spx.ts_ms); spx=spx[(spx.t>="2026-11-12 09:30")&(spx.t<="2026-11-12 16:00")]
snaps=np.sort(cs.ts_ms.unique()); st=et(pd.Series(snaps))
o=spx.iloc[0]["open"]
def guide(rows_c, rows_g, ref, S0):
    W1,W2=1.0*S0,2.0*S0
    cl=B.signed_clusters(rows_c, ref-W2, ref+W2, min_share=0.01)
    gm=dict(zip(rows_g.strike, rows_g.signed_pct))
    for c in cl: c["g"]=sum(abs(gm.get(k,0)) for k,_ in c["bars"])
    out={}
    for side,nm in ((1,"up"),(-1,"dn")):
        sh=[c for c in cl if c["sign"]<0 and side*(c["peak"]-ref)>0]
        a=[c for c in sh if abs(c["peak"]-ref)<=W1]; b=[c for c in sh if W1<abs(c["peak"]-ref)<=W2]
        out[nm+"1"]=max(a,key=lambda c:c["mass"])["peak"] if a else (min(b,key=lambda c:abs(c["peak"]-ref))["peak"] if b else np.nan)
        b2=[c for c in sh if side*(c["peak"]-out[nm+"1"])>0] if out[nm+"1"]==out[nm+"1"] else []
        out[nm+"2"]=max(b2,key=lambda c:c["mass"])["peak"] if b2 else np.nan
    lg=[c for c in cl if c["sign"]>0 and (np.isnan(out["up1"]) or c["peak"]<out["up1"]) and (np.isnan(out["dn1"]) or c["peak"]>out["dn1"])]
    out["bal"]=max(lg,key=lambda c:c["g"])["peak"] if lg else np.nan
    return out
rec=[]; snap_rows={}
S0=None
for ms,t in zip(snaps,st):
    if t<pd.Timestamp("2026-11-12 09:35") or t.minute%5: continue
    ch=cs[cs.ts_ms==ms]; sp=ch.spot.iloc[0]
    if S0 is None: S0=B.mid_straddle(ch,o); print("lock",t,"open",o,"S0",S0)
    rc=B.signed_book_rows(ch,sp,units="contracts"); rg=B.signed_book_rows(ch,sp,units="gex")
    cur=B.dan_levels_from_rows(rc,o,S0)
    r=dict(t=t,spot=sp)
    r["c_up1"]=cur["ups"][0]["peak"] if cur["ups"] else np.nan
    r["c_up2"]=cur["ups"][1]["peak"] if len(cur["ups"])>1 else np.nan
    r["c_dn1"]=cur["dns"][0]["peak"] if cur["dns"] else np.nan
    r["c_dn2"]=cur["dns"][1]["peak"] if len(cur["dns"])>1 else np.nan
    r["c_bal"]=cur["bal"]["peak"] if cur["bal"] else np.nan
    g=guide(rc,rg,o,S0); r.update({"g_"+k:v for k,v in g.items()})
    rec.append(r); snap_rows[t]=(rc,rg)
R=pd.DataFrame(rec).set_index("t"); print(R.iloc[::3].to_string())
pd.to_pickle(dict(R=R,spx=spx,snap_rows=snap_rows,S0=S0,o=o),"lv.pkl")
